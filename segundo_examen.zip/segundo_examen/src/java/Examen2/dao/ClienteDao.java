/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Examen2.dao;

import Examen2.model.Usuarios;
import java.util.List;
import java.util.Map;


public interface ClienteDao {
    int create(Usuarios cliente);

    int update(Usuarios cliente);

    int delete(int idcliente);

    Usuarios read(int idcliente);
    List<Map<String , Object>> readAll();
}
