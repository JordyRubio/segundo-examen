/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Examen2.dao;

import Examen2.model.Sucurssales;
import java.util.List;
import java.util.Map;


public interface SucursalDao {
    int create(Sucurssales sucursales);
    int update(Sucurssales sucursales);
    int delete(int idsucursal);
    Sucurssales read(int idsucursales);
    List<Map<String , Object>> readAll();
}
