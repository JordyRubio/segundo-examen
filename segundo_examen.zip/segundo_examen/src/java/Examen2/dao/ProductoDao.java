/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Examen2.dao;

import Examen2.model.Productos;
import java.util.List;
import java.util.Map;


public interface ProductoDao {
    int create(Productos producto);
    int update(Productos producto);
    int delete(int idproducto);
    Productos read(int idproducto);
    List<Map<String , Object>> readAll();
}
