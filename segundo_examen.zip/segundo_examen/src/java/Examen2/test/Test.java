/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Examen2.test;

import com.google.gson.Gson;
import Examen2.config.Conexion;
import Examen2.daoImpl.SucursalDaoImpl;
import Examen2.dao.SucursalDao;
/**
 *
 * @author admin
 */
public class Test {
    static Gson g = new Gson();

    
    static SucursalDao succu = new SucursalDaoImpl();
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        if (Conexion.getConexion() != null) {
            System.out.println("si");
        } else {
            System.out.println("no");
        }
      System.out.println(g.toJson(succu.readAll()));
    }
}




