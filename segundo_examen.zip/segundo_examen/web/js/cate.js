$(document).ready(function () {

     listarvendedor();
     listarVentas();
     listarSucursales();
     listarClientes();
     listarProductos();

});
let xx;
function listarVentas() {


    $.get("venta", {"opc": 1}, function (data) {

        let x = JSON.parse(data);
        $("#tabla tbody tr").remove();
        for (let i = 0; i < x.length; i++) {
            $("#tabla").append(
                    "<tr><td>" + (i + 1) + "</td><td>" + x[i].idventa + "</td><td>" + x[i].sucursal +
                    "</td><td>" + x[i].vendedor + "</td><td>" + x[i].fecha + "</td><td><a href='#'><i class='fa-solid fa-eye'></i></a></td>");
        }

    });
}
function listarvendedor() {
    $.get("usuario", {"opc": 1}, function (data)    {
        let x = JSON.parse(data);
        for (let i = 0; i < x.length; i++) {
            $("#vendedor").append($("<option>", {
                value: x[i],
                text: x[i].user

            })
                    );

        }

    });
}
function listarSucursales() {
       $.get("sucursal", {"opc": 1}, function (data)    {
        let x = JSON.parse(data);
        for (let i = 0; i < x.length; i++) {
            $("#sucursal").append($("<option>", {
                value: x[i],
                text: x[i].nombre

            })
                    );

        }

    });
}

function listarClientes() {
    $.get("cliente", {"opc": 1}, function (data)
    {
        console.log(data);
        let x = JSON.parse(data);
        for (let i = 0; i < x.length; i++) {
            $("#cliente").append($("<option>", {
                value: x[i],
                text: x[i].nombre

            })
                    );

        }

    });

}
function listarProductos() {

    $.get("producto", {"opc": 1}, function (data)    {
        let x = JSON.parse(data);
        for (let i = 0; i < x.length; i++) {
            $("#producto").append($("<option>", {
                value: x[i],
                text: x[i].nombre

            })
                    );

        }

    });
}
let mostrar = () => {
    const valor = $("#producto :selected").val(),
            texto = $("#producto :selected").text();
    $('#producto').val(texto);
};


$('#producto').change(mostrar);